# TodoApp
## MongoDB + Node Express with MVC Architecture
<img src="https://github.com/rstudy211/TodoApp/blob/main/Screenshot%202022-09-24%20at%2011.58.52%20PM.png"/>
